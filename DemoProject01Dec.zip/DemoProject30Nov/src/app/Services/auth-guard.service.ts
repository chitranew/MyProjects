import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {

  constructor(private router: Router) { }
  canActivate(): boolean {
    let bool = false;
    if (localStorage.getItem('canActive') === 'true') {
      bool = true;
    }
    else{
      this.router.navigate(['login']);
      bool = false;
    }
    return bool;
  }
}
