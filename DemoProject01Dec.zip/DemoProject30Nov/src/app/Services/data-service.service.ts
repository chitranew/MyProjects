import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {
  private apiUrl="http://localhost:3000/posts";
  private matchUrl="assets/json/matches.json";

  constructor(
    private http: HttpClient
  ) { }

  public getData(){
    return this.http.get(this.apiUrl);
  }
  public postData(data:any){
    return this.http.post(this.apiUrl,data);
  }

  public getMatchData(){
    return this.http.get(this.matchUrl);
  }
}
