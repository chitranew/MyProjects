import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../Services/data-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  dispStr1:any=[];
  dispStr2:any=[];

  matchData:any=[];
  winnerList:any=[];
  winnerCount:any=[];

 patType='';

  constructor( private router:Router, private api : DataServiceService) { }

  ngOnInit(): void {
   this.getMatchData();
  }
  getMatchData(){
    let temp=this.api.getMatchData().subscribe(res=>{
     
      this.matchData=res;
      for(let i in this.matchData){
        if(this.matchData[i].season== 2008){
          this.winnerList.push(this.matchData[i].winner);
        }
      }
      const map =  this.winnerList.reduce((acc, e) => acc.set(e, (acc.get(e) || 0) + 1), new Map());
      this.winnerCount=[...map.entries()];
      console.log(this.winnerCount);
    })
  }
  pattern1(){
   let patternStr='';
    for(let i=0;i<5;i++){
      patternStr='';
      for(let j=0;j<=i;j++){
        patternStr=patternStr+"* ";
       
      }
      patternStr=patternStr+"\n";
      this.dispStr1[i]=patternStr;
      console.log(patternStr);
    }
    this.patType='pat1';
  }

  pattern2(){

    let n = 4;
    let count=0;
    let string = "";
    let temp="";
    for (let i = 0; i < n; i++) {
    temp='';
      for (let j = 0; j < i; j++) {
        string += " ";
        temp+=' ';
      }
    
      for (let k = 0; k < (n - i) * 2 - 1; k++) {
        string += "*";
        temp += "*";
      }
      string += "\n";
      temp += "\n";
      this.dispStr2[count]=temp;
      count++;
    }

    for (let i = 2; i <= n; i++) {
    temp='';
      for (let j = n; j > i; j--) {
        string += " ";
        temp += " ";
      }
      
      for (let k = 0; k < i * 2 - 1; k++) {
        string += "*";
        temp += "*";
      }
      string += "\n";
      temp += "\n";
      temp=string;
     
      
    }
    console.log(string);
   
    this.patType='pat2';
  }

  logout(){
    this.router.navigate(['']);
  }
}
