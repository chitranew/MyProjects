import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../Services/data-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userName='';
  password='';
  confirmPwd='';
  userData:any=[];
  userNames:any=[];
  alert='';
  validUser=false;
  constructor(
    private api:DataServiceService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.validUser=false;
    this.getData();
  }
  getData() {
    let temp=this.api.getData().subscribe(res=>{
      this.userData=res;
      for(let i in this.userData){
        this.userNames[i]=this.userData[i].userName;
      }
    })
  }
  isValid(){
    if(this.userName=='' || this.password==''){
      this.showAlert('All fields required');
      return false;
    } else{
      return true;
    }

  }
  login(){
    
    if(this.isValid()){
      if(this.userNames.includes(this.userName)){
        for(let i in this.userData){
         
            if(this.userData[i].userName==this.userName && this.userData[i].password==this.password){
              this.validUser=true;
            } 
        }
        if(this.validUser){
          this.showAlert('Login Success');
          localStorage.setItem('canActive', 'true');
          this.router.navigate(['home']);
        } else{
          this.showAlert('Invalid Credentials');
          this.userName='';
          this.password='';
        }
      }else{
        this.showAlert('User does not exist');
      }
    }
    
  }

   showAlert(msg:string){
    this.alert=msg;
    //setTimeout(this.alert='',5000);
   }
}
