import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../Services/data-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
   userName='';
   password='';
   confirmPwd='';
   userData:any=[];
   alert='';
  constructor( private api:DataServiceService, private router: Router) { }

  ngOnInit(): void {
    this.getData();
  }
  getData() {
    let temp=this.api.getData().subscribe(res=>{
      this.userData=res;
    })
  }
  isValid(){
    if(this.userName=='' || this.password=='' || this.confirmPwd==''){
      this.showAlert('All fields required');
      return false;
    }else if(this.password != this.confirmPwd){
      this.showAlert('Password and Confirm Password does not match');
      return false;
    } else{
      return true;
    }

  }
  signup(){
    if(this.isValid()){
      for(let i in this.userData) {
      
         if(this.userData[i].userName==this.userName){
        this.showAlert('User already exists'); 
          return;
         }
       }
       let data={userName:this.userName, password:this.password, confirmPassword:this.confirmPwd};
       let temp=this.api.postData(data).subscribe(res=>{
        this.showAlert('Sign up done');
        this.router.navigate(['login']);
       })

    }
    
   }
   showAlert(msg:string){
    this.alert=msg;
    //setTimeout(this.alert='',5000);
   }
   login(){
    this.router.navigate(['']);
  }
}
